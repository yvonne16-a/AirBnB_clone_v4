** Web Static AirBnB
